	<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="text" name="s" id="s" placeholder="Enter keywords...">
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="Search">
	</form>
